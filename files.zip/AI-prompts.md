# AI Prompt Templates

## ChatGPT

- “Summarize this n8n workflow and suggest improvements.”
- “Write a brief, friendly reply to a Shopify customer’s inquiry about order status.”
- “Generate a step-by-step guide for automating order notifications with n8n and Slack.”

## Claude

- “Review this workflow and fix any errors in the logic.”
- “Provide a checklist for onboarding a new Shopify automation.”
- “Analyze this text and extract the main action points for our team.”

---

## General Prompt Tips

- Always tell the AI what tool or platform you’re using.
- Paste your workflow, code, or error message for best results.
- If you’re stuck, just ask: “What am I missing?” or “How can I improve this?”

---

Feel free to add your own prompt ideas here!