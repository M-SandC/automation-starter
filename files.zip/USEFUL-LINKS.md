# Useful Links & Resources

- [n8n Community Workflows](https://github.com/n8n-io/n8n-community-workflows)
- [Shopify API Docs](https://shopify.dev/docs/api)
- [Supabase GitHub](https://github.com/supabase/supabase)
- [Public APIs](https://github.com/public-apis/public-apis)
- [Awesome Shopify](https://github.com/julionery/awesome-shopify)
- [OpenAI Cookbook](https://github.com/openai/openai-cookbook)

---

## How to Use These

- Browse for inspiration and ready-to-use automations
- Copy/paste examples into n8n or your AI tools
- Save cool links you find for later
